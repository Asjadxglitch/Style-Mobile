import { Button } from "@/components/ui/button";
import { ShoppingCart, ArrowLeft, Filter } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

/**
 * Design Philosophy: Modern Tech-Forward Minimalism
 * - Product grid with hover effects and clear pricing
 * - Filter sidebar for category selection
 * - Responsive grid layout
 */

export default function Shop() {
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [cartCount, setCartCount] = useState(0);

  const categories = ["all", "cases", "screen-protectors", "chargers", "cables", "accessories"];

  const products = [
    {
      id: 1,
      name: "Premium Leather Phone Case",
      category: "cases",
      price: "LKR 1,299",
      rating: 4.8,
      reviews: 124,
    },
    {
      id: 2,
      name: "Tempered Glass Screen Protector",
      category: "screen-protectors",
      price: "LKR 599",
      rating: 4.9,
      reviews: 89,
    },
    {
      id: 3,
      name: "Wireless Charging Pad",
      category: "chargers",
      price: "LKR 2,499",
      rating: 4.7,
      reviews: 156,
    },
    {
      id: 4,
      name: "Fast USB-C Cable",
      category: "cables",
      price: "LKR 449",
      rating: 4.6,
      reviews: 78,
    },
    {
      id: 5,
      name: "Phone Stand",
      category: "accessories",
      price: "LKR 799",
      rating: 4.5,
      reviews: 45,
    },
    {
      id: 6,
      name: "Silicone Case (Assorted Colors)",
      category: "cases",
      price: "LKR 899",
      rating: 4.7,
      reviews: 102,
    },
    {
      id: 7,
      name: "Car Phone Mount",
      category: "accessories",
      price: "LKR 1,099",
      rating: 4.8,
      reviews: 67,
    },
    {
      id: 8,
      name: "20W Fast Charger",
      category: "chargers",
      price: "LKR 1,999",
      rating: 4.9,
      reviews: 134,
    },
    {
      id: 9,
      name: "Screen Protector (Pack of 3)",
      category: "screen-protectors",
      price: "LKR 1,299",
      rating: 4.8,
      reviews: 91,
    },
  ];

  const filteredProducts =
    selectedCategory === "all"
      ? products
      : products.filter((p) => p.category === selectedCategory);

  const handleAddToCart = () => {
    setCartCount(cartCount + 1);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/style-mobile-logo-mK2SHFUqxFbizWudSRSeG4.png"
              alt="Style Mobile"
              className="h-10 w-auto"
            />
            <span className="text-2xl font-bold text-foreground">Style Mobile</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/cart")}
              className="relative p-2 hover:bg-muted rounded-lg transition-colors"
            >
              <ShoppingCart className="w-6 h-6 text-foreground" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-primary text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-12">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Shop All Products</h1>
          <p className="text-muted-foreground">
            Browse our complete collection of mobile accessories
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-card rounded-lg p-6 border border-border sticky top-20">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">Categories</h2>
              </div>

              <div className="space-y-3">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-left px-4 py-2 rounded-lg transition-all ${
                      selectedCategory === category
                        ? "bg-primary text-white font-semibold"
                        : "text-foreground hover:bg-muted"
                    }`}
                  >
                    {category.charAt(0).toUpperCase() +
                      category.slice(1).replace("-", " ")}
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-border">
                <h3 className="font-semibold text-foreground mb-4">Price Range</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>LKR 0 - LKR 50,000</p>
                  <p className="text-xs">Adjust filters to see prices</p>
                </div>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="lg:col-span-3">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Showing {filteredProducts.length} products
              </p>
              <select className="px-4 py-2 border border-border rounded-lg bg-white text-foreground">
                <option>Sort by: Newest</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Most Popular</option>
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="group bg-card rounded-lg overflow-hidden border border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="relative h-48 overflow-hidden bg-muted">
                    <div className="w-full h-full bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl mb-2">📱</div>
                        <p className="text-sm text-muted-foreground">Product Image</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-2 line-clamp-2">
                      {product.name}
                    </h3>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <span key={i} className="text-sm">
                            ★
                          </span>
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary">
                        {product.price}
                      </span>
                      <Button
                        size="sm"
                        className="bg-primary hover:bg-primary/90 text-white"
                        onClick={handleAddToCart}
                      >
                        <ShoppingCart className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">
                  No products found in this category
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
