import { Button } from "@/components/ui/button";
import { ShoppingCart, Phone, Zap, Lock } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

/**
 * Design Philosophy: Modern Tech-Forward Minimalism
 * - Clean white backgrounds with vibrant orange (#FF6B35) and cyan (#0099FF) accents
 * - Premium product showcase with asymmetric layouts
 * - Smooth animations and interactions
 */

export default function Home() {
  const [, navigate] = useLocation();
  const [cartCount, setCartCount] = useState(0);

  const featuredProducts = [
    {
      id: 1,
      name: "Premium Phone Case",
      price: "LKR 1,299",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/featured-products-bg-eAZzKhBKsJJgTGUniWuMiN.webp",
      rating: 4.8,
      reviews: 124,
    },
    {
      id: 2,
      name: "Tempered Glass Screen Protector",
      price: "LKR 599",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/featured-products-bg-eAZzKhBKsJJgTGUniWuMiN.webp",
      rating: 4.9,
      reviews: 89,
    },
    {
      id: 3,
      name: "Wireless Charging Pad",
      price: "LKR 2,499",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/featured-products-bg-eAZzKhBKsJJgTGUniWuMiN.webp",
      rating: 4.7,
      reviews: 156,
    },
  ];

  const handleAddToCart = () => {
    setCartCount(cartCount + 1);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/style-mobile-logo-mK2SHFUqxFbizWudSRSeG4.png"
              alt="Style Mobile"
              className="h-10 w-auto"
            />
            <span className="text-2xl font-bold text-foreground">Style Mobile</span>
          </div>

          <nav className="hidden md:flex gap-8">
            <a href="#" className="text-foreground hover:text-primary transition-colors">
              Home
            </a>
            <a href="#shop" className="text-foreground hover:text-primary transition-colors">
              Shop
            </a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors">
              About
            </a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors">
              Contact
            </a>
          </nav>

          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/cart")}
              className="relative p-2 hover:bg-muted rounded-lg transition-colors"
            >
              <ShoppingCart className="w-6 h-6 text-foreground" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-primary text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            <Button
              onClick={() => navigate("/admin")}
              variant="outline"
              className="hidden sm:inline-flex"
            >
              Admin
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/hero-mobile-accessories-aNHMMUDri6GLYSDn8ccp3P.webp')",
          }}
        />
        <div className="relative container py-20 md:py-32">
          <div className="max-w-2xl">
            <div className="flex items-center gap-4 mb-6">
              <img
                src="/manus-storage/images_3af92f35.png"
                alt="Style Mobile Logo"
                className="h-20 w-auto"
              />
              <div className="h-1 w-16 bg-primary rounded-full" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-4">
              Premium Mobile Accessories
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-xl">
              Discover our curated collection of high-quality phone cases, screen protectors, chargers, and more. Protect your device in style.
            </p>
            <div className="flex gap-4">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-white"
                onClick={() => navigate("/shop")}
              >
                Shop Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary/5"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-muted/30 py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-lg mb-4">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Fast Delivery</h3>
              <p className="text-muted-foreground">
                Get your order delivered within 24-48 hours across Colombo
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary/10 rounded-lg mb-4">
                <Lock className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Secure Payment</h3>
              <p className="text-muted-foreground">
                Multiple payment options including Koko, bank transfer, and card
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-lg mb-4">
                <Phone className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">24/7 Support</h3>
              <p className="text-muted-foreground">
                Contact us via WhatsApp, Facebook, or call for instant assistance
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section id="shop" className="py-20">
        <div className="container">
          <div className="mb-12">
            <div className="h-1 w-16 bg-primary rounded-full mb-4" />
            <h2 className="text-4xl font-bold text-foreground mb-2">Featured Products</h2>
            <p className="text-muted-foreground">
              Handpicked selection of our best-selling mobile accessories
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-card rounded-lg overflow-hidden border border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <div className="relative h-64 overflow-hidden bg-muted">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 right-3 bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">
                    New
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className="text-sm">
                          ★
                        </span>
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">{product.price}</span>
                    <Button
                      size="sm"
                      className="bg-primary hover:bg-primary/90 text-white"
                      onClick={handleAddToCart}
                    >
                      <ShoppingCart className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={() => navigate("/shop")}
            >
              View All Products
            </Button>
          </div>
        </div>
      </section>

      {/* Payment Methods Section */}
      <section className="bg-muted/50 py-20">
        <div className="container">
          <div className="mb-12 text-center">
            <div className="h-1 w-16 bg-primary rounded-full mb-4 mx-auto" />
            <h2 className="text-4xl font-bold text-foreground mb-2">Payment Methods</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We accept multiple payment options for your convenience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-8 border border-border text-center hover:shadow-md transition-shadow">
              <div className="text-4xl mb-4">💳</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Card Payment</h3>
              <p className="text-muted-foreground">
                Visa, Mastercard, and other major credit/debit cards accepted
              </p>
            </div>
            <div className="bg-white rounded-lg p-8 border border-border text-center hover:shadow-md transition-shadow">
              <div className="text-4xl mb-4">🏦</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Bank Transfer</h3>
              <p className="text-muted-foreground">
                Direct bank transfer with competitive rates and instant confirmation
              </p>
            </div>
            <div className="bg-white rounded-lg p-8 border border-border text-center hover:shadow-md transition-shadow">
              <div className="text-4xl mb-4">📱</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Koko Payment</h3>
              <p className="text-muted-foreground">
                Fast and secure payment through Koko mobile payment gateway
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <div className="h-1 w-16 bg-primary rounded-full mb-4 mx-auto" />
            <h2 className="text-4xl font-bold text-foreground mb-4">Get In Touch</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Have questions? We're here to help! Contact us through any of these channels.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-card rounded-lg p-6 border border-border">
                <h3 className="font-semibold text-foreground mb-2">📍 Address</h3>
                <p className="text-muted-foreground">
                  8 Piliyandala - Maharagama Rd, Maharagama 10280, Sri Lanka
                </p>
              </div>
              <div className="bg-card rounded-lg p-6 border border-border">
                <h3 className="font-semibold text-foreground mb-2">📞 Phone</h3>
                <p className="text-muted-foreground">077 550 6050</p>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="https://wa.me/94775506050"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg font-semibold transition-colors"
              >
                💬 WhatsApp
              </a>
              <a
                href="https://web.facebook.com/stylemobilelk"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors"
              >
                f Facebook
              </a>
              <a
                href="https://www.tiktok.com/@stylemobilelk"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-black hover:bg-gray-800 text-white rounded-lg font-semibold transition-colors"
              >
                🎵 TikTok
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">About Style Mobile</h4>
              <p className="text-white/70">
                Your trusted source for premium mobile accessories in Maharagama
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-white/70">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Shop
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Payment Methods</h4>
              <ul className="space-y-2 text-white/70">
                <li>Card Payment</li>
                <li>Bank Transfer</li>
                <li>Koko Payment</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <a
                  href="https://web.facebook.com/stylemobilelk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-primary transition-colors"
                >
                  Facebook
                </a>
                <a
                  href="https://www.tiktok.com/@stylemobilelk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-primary transition-colors"
                >
                  TikTok
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-white/70">
            <p>&copy; 2026 Style Mobile. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
