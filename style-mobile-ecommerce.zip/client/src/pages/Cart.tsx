import { Button } from "@/components/ui/button";
import { ArrowLeft, Trash2 } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

/**
 * Design Philosophy: Modern Tech-Forward Minimalism
 * - Clean cart layout with clear pricing breakdown
 * - Payment method selection with visual indicators
 * - Responsive checkout flow
 */

export default function Cart() {
  const [, navigate] = useLocation();
  const [selectedPayment, setSelectedPayment] = useState("koko");
  const [showCheckout, setShowCheckout] = useState(false);

  const cartItems = [
    {
      id: 1,
      name: "Premium Phone Case",
      price: 1299,
      quantity: 1,
      image: "📱",
    },
    {
      id: 2,
      name: "Tempered Glass Screen Protector",
      price: 599,
      quantity: 2,
      image: "🔒",
    },
  ];

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 200;
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + shipping + tax;

  const paymentMethods = [
    {
      id: "koko",
      name: "Koko Payment",
      description: "Fast and secure mobile payment",
      icon: "📱",
    },
    {
      id: "bank",
      name: "Bank Transfer",
      description: "Direct bank transfer",
      icon: "🏦",
    },
    {
      id: "card",
      name: "Card Payment",
      description: "Visa, Mastercard, and more",
      icon: "💳",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663654236826/QHtkuGUr5Zxwhh3KWgbf6y/style-mobile-logo-mK2SHFUqxFbizWudSRSeG4.png"
              alt="Style Mobile"
              className="h-10 w-auto"
            />
            <span className="text-2xl font-bold text-foreground">Style Mobile</span>
          </div>

          <Button
            onClick={() => navigate("/shop")}
            variant="outline"
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Continue Shopping
          </Button>
        </div>
      </header>

      <div className="container py-12">
        <h1 className="text-4xl font-bold text-foreground mb-8">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-card rounded-lg border border-border overflow-hidden">
              {cartItems.length > 0 ? (
                <div className="divide-y divide-border">
                  {cartItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-6 flex items-center justify-between hover:bg-muted/30 transition-colors"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className="text-4xl">{item.image}</div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground">
                            {item.name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            Quantity: {item.quantity}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-primary">
                          LKR {(item.price * item.quantity).toLocaleString()}
                        </p>
                        <button className="text-destructive hover:text-destructive/80 transition-colors mt-2">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-12 text-center">
                  <p className="text-muted-foreground text-lg">Your cart is empty</p>
                  <Button
                    onClick={() => navigate("/shop")}
                    className="mt-4 bg-primary hover:bg-primary/90 text-white"
                  >
                    Start Shopping
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-card rounded-lg border border-border p-6 sticky top-20">
              <h2 className="text-xl font-bold text-foreground mb-6">Order Summary</h2>

              <div className="space-y-4 mb-6 pb-6 border-b border-border">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>LKR {subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span>LKR {shipping.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Tax (5%)</span>
                  <span>LKR {tax.toLocaleString()}</span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-6">
                <span className="text-lg font-bold text-foreground">Total</span>
                <span className="text-2xl font-bold text-primary">
                  LKR {total.toLocaleString()}
                </span>
              </div>

              <Button
                onClick={() => setShowCheckout(true)}
                className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3"
              >
                Proceed to Checkout
              </Button>
            </div>
          </div>
        </div>

        {/* Checkout Modal */}
        {showCheckout && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b border-border p-6 flex items-center justify-between">
                <h2 className="text-2xl font-bold text-foreground">Checkout</h2>
                <button
                  onClick={() => setShowCheckout(false)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  ✕
                </button>
              </div>

              <div className="p-6 space-y-8">
                {/* Shipping Information */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Shipping Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="First Name"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="text"
                      placeholder="Last Name"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="email"
                      placeholder="Email"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary md:col-span-2"
                    />
                    <input
                      type="tel"
                      placeholder="Phone Number"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary md:col-span-2"
                    />
                    <input
                      type="text"
                      placeholder="Address"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary md:col-span-2"
                    />
                    <input
                      type="text"
                      placeholder="City"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="text"
                      placeholder="Postal Code"
                      className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>

                {/* Payment Method Selection */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Select Payment Method
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {paymentMethods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setSelectedPayment(method.id)}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          selectedPayment === method.id
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <div className="text-3xl mb-2">{method.icon}</div>
                        <h4 className="font-semibold text-foreground">
                          {method.name}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {method.description}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Payment Details Based on Selection */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Payment Details
                  </h3>
                  {selectedPayment === "koko" && (
                    <div className="bg-muted/30 p-4 rounded-lg border border-border">
                      <p className="text-foreground font-semibold mb-2">
                        Koko Payment Gateway
                      </p>
                      <p className="text-muted-foreground text-sm">
                        You will be redirected to Koko payment gateway to complete
                        your transaction securely.
                      </p>
                      <div className="mt-4 p-3 bg-white rounded border border-border">
                        <p className="text-sm font-semibold text-foreground">
                          Amount: LKR {total.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  )}
                  {selectedPayment === "bank" && (
                    <div className="bg-muted/30 p-4 rounded-lg border border-border">
                      <p className="text-foreground font-semibold mb-2">
                        Bank Transfer Details
                      </p>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <p>
                          <strong>Bank:</strong> Commercial Bank of Ceylon
                        </p>
                        <p>
                          <strong>Account Name:</strong> Style Mobile
                        </p>
                        <p>
                          <strong>Account Number:</strong> XXXX XXXX XXXX 1234
                        </p>
                        <p>
                          <strong>Amount:</strong> LKR {total.toLocaleString()}
                        </p>
                      </div>
                      <p className="text-xs text-muted-foreground mt-4">
                        Please contact us on WhatsApp after transfer for confirmation
                      </p>
                    </div>
                  )}
                  {selectedPayment === "card" && (
                    <div className="space-y-4">
                      <input
                        type="text"
                        placeholder="Card Number"
                        className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <input
                          type="text"
                          placeholder="CVV"
                          className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Order Summary in Modal */}
                <div className="bg-card rounded-lg border border-border p-4">
                  <h4 className="font-semibold text-foreground mb-3">
                    Order Summary
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Subtotal</span>
                      <span>LKR {subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Shipping</span>
                      <span>LKR {shipping.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Tax</span>
                      <span>LKR {tax.toLocaleString()}</span>
                    </div>
                    <div className="border-t border-border pt-2 flex justify-between font-bold text-foreground">
                      <span>Total</span>
                      <span className="text-primary">
                        LKR {total.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button
                    onClick={() => setShowCheckout(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button className="flex-1 bg-primary hover:bg-primary/90 text-white font-semibold">
                    Complete Order
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
